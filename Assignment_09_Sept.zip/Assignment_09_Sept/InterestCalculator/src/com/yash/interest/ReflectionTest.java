package com.yash.interest;

import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;




public class ReflectionTest{
	public static void main(String args[]) {
		
		Person p = new Person();
		Class cls = p.getClass();
		
		
		Constructor constructor;
		try {
			constructor = cls.getConstructor();
	        System.out.println("The name of constructor is " +
	                            constructor.getName());
		
	        
	        Class classData=Class.forName("com.yash.interest.Person");
	    	
			//dynamic object initialization
	        Person someClassObject=(Person)classData.newInstance();
		
			Method[] methods = classData.getDeclaredMethods();

			  for(Method method : methods){
				  System.out.println(method);
			  }	
			  Class[] inter =classData.getInterfaces();
			  for(Class method : inter){
				  System.out.println(method);
			  }
			  
		} catch (NoSuchMethodException | SecurityException | ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}


class Person implements Serializable{
	
	private static final long serialVersionUID = 9053144723751460281L;
	
	int personId;
	String personName;
	int personAge;
	String personLocation;
	
	public Person() {
		super();
	}
	
	public Person(int personId, String personName, int personAge, String personLocation) {
		super();
		this.personId = personId;
		this.personName = personName;
		this.personAge = personAge;
		this.personLocation = personLocation;
	}
	
	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public int getPersonAge() {
		return personAge;
	}
	public void setPersonAge(int personAge) {
		this.personAge = personAge;
	}
	public String getPersonLocation() {
		return personLocation;
	}
	public void setPersonLocation(String personLocation) {
		this.personLocation = personLocation;
	}

}