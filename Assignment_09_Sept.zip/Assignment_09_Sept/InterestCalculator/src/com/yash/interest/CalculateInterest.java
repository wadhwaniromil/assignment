package com.yash.interest;

import java.util.Scanner;

public class CalculateInterest {

	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);
		InterestCalculator c = new InterestCalculator();
		System.out.println("Enter amount to calculate interest");
		double amount = sc.nextDouble();
		sc.nextLine();

		System.out.println("Enter time period");
		double period = sc.nextDouble();
		sc.nextLine();
	
		System.out.println("Enter interest rate");
		double interestRate = sc.nextDouble();
		sc.nextLine();
		
		System.out.println("Please choose a option");
		System.out.println("1. Calculate compound interest");
		System.out.println("2. Calculate simple interest");
		int option = sc.nextInt();
		
		switch (option) {
		case 1:
			System.out.println("Calculated Compound Interest:");
			System.out.println(c.calculateCompoundInterest(amount, period, interestRate));
			break;

		case 2: 
			System.out.println("Calculated Simple Interest:");
			System.out.println(c.simpleInterest(amount, period, interestRate));
			break;
			
		default:
			System.out.println("Please select valid option");
			break;
		}
	}

}

class InterestCalculator implements IntersetCalculator{

	@Override
	public double calculateCompoundInterest(double principleAmount, double timePeriod, double interestRate) {
		double interest = principleAmount*(Math.pow((1+interestRate/100), timePeriod));
		return interest;
	}

	@Override
	public double simpleInterest(double principleAmount, double timePeriod, double interestRate) {
		double interest = (principleAmount*timePeriod*interestRate)/100;
		return interest;
	}
}

interface IntersetCalculator{
	public double calculateCompoundInterest(double principleAmount, double timePeriod, double interestRate);
	public double simpleInterest(double principleAmount, double timePeriod, double interestRate);
}