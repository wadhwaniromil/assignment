package com.yash.record;

import java.util.Scanner;

import com.yash.model.Student;

public class StudentRecord {

	static Student studentArray[] = new Student[7];
	static int studentCount = 0;

	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		boolean hasNext = true;
		int studentRollNumber;
		while(hasNext) {
			
			System.out.println("Please select an option below:");
			System.out.println("1. Register a new student");
			System.out.println("2. View record of a student");
			System.out.println("3. Update record of a student");
			System.out.println("4. Delete record of a student");
			System.out.println("5. Exit");
			int chosenOption = sc.nextInt();
			
			switch (chosenOption) {
			case 1:
				registerStudentRecord();
				break;
		
			case 2:
				System.out.println("Please enter student's roll number to view record");
				studentRollNumber = sc.nextInt();
				viewStudentRecord(studentRollNumber);
				break;
			
			case 3:
				System.out.println("Please enter student's roll number to update record");
				studentRollNumber = sc.nextInt();
				updateStudentRecord(studentRollNumber);
				break;
			
			case 4:
				System.out.println("Please enter student's roll number to delete record");
				studentRollNumber = sc.nextInt();
				deleteStudentRecord(studentRollNumber);
				break;
			
			case 5:
				System.out.println("Have a nice day!");
				hasNext = false;
				break;

			default:
				System.out.println("Please Select a valid option");
				break;
			}
			
		}

	}


	private static void deleteStudentRecord(int studentRollNumber) {
		for(int i =0; i<studentArray.length;i++) {
			if(studentArray[i] != null && studentArray[i].getStudentRollNumber() == studentRollNumber) {
				studentArray[i] = null;
				System.out.println("Student Record deleted successfully!");
			}
		}	
		
		
	}


	private static void updateStudentRecord(int studentRollNumber) {
		
		System.out.println("Enter student's roll number");
		int roll = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter student's name");
		String name = sc.nextLine();
		System.out.println("Enter student's branch");
		String branch = sc.nextLine();
		System.out.println("Enter student's section");
		String section = sc.nextLine();
	
		
		for(Student s: studentArray) {
			if(s != null && s.getStudentRollNumber() == studentRollNumber) {
				s.setStudentRollNumber(roll);
				s.setStudentName(name);
				s.setStudentBranch(branch);
				s.setStudentSection(section);
				System.out.println("Student record updated!");
			}
		}		
	}


	private static void viewStudentRecord(int studentRollNumber) {
		System.out.println("Record of Student having roll number: " + studentRollNumber);

		for(Student s: studentArray) {
			if(s != null && s.getStudentRollNumber() == studentRollNumber) {
				System.out.println(s.toString());
			}
		}	
	}


	private static void registerStudentRecord() {
		if(studentCount < 7) {
			System.out.println("Enter student's roll number");
			int roll = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter student's name");
			String name = sc.nextLine();
			System.out.println("Enter student's branch");
			String branch = sc.nextLine();
			System.out.println("Enter student's section");
			String section = sc.nextLine();
		
			studentArray[studentCount] = new Student(roll, name, branch, section);
			studentCount++;
		}else {
			System.out.println("Storage full. Please delete some records!");
		}
	}

}
