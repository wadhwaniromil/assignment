package com.yash.model;

public class Student {

	int studentRollNumber;
	String studentName;
	String studentBranch;
	String studentSection;
		
	public Student(int studentRollNumber, String studentName, String studentBranch, String studentSection) {
		super();
		this.studentRollNumber = studentRollNumber;
		this.studentName = studentName;
		this.studentBranch = studentBranch;
		this.studentSection = studentSection;
	}

	public int getStudentRollNumber() {
		return studentRollNumber;
	}

	public void setStudentRollNumber(int studentRollNumber) {
		this.studentRollNumber = studentRollNumber;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentBranch() {
		return studentBranch;
	}

	public void setStudentBranch(String studentBranch) {
		this.studentBranch = studentBranch;
	}

	public String getStudentSection() {
		return studentSection;
	}

	public void setStudentSection(String studentSection) {
		this.studentSection = studentSection;
	}

	@Override
	public String toString() {
		return "Student [studentRollNumber=" + studentRollNumber + ", studentName=" + studentName + ", studentBranch="
				+ studentBranch + ", studentSection=" + studentSection + "]";
	}
}
